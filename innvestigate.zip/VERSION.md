## Version 1.0.8

Bugfixes, increased code covervage, CI.

## Version 1.0.7

Add Python 2 compatibility again.

Bugfixes.

## Version 1.0.6

* Add beta version of DeepLIFT (as in Ancona et.al.) and wrapper for DeepLIFT package.
* Updating readme and bugfixes.

## Version 1.0.5

Treat IntegratedGradients as attribution method and bugfixes.

## Version 1.0.1-1.0.4

Added the following functionality:

* Additional notebooks.
* Analyzers: Input\*Gradient
* Added parameter to choose between plain, abs, square gradient in Gradient analyzer.
* New interface via register-methods in analyzer base code.
* Many fixes.
* Support for read-the-docs documentation.

## Version 1.0.0

Includes the following functionality:

* Analyzers: Gradient, SmoothGrad, IntegratedGradients, PatternNet, PatternAttribution, LRP, DeepTaylor, Input, Random.
* Pattern computer.
