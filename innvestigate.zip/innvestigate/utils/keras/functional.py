import tensorflow as tf
import tensorflow.keras.backend as K
import tensorflow.keras.layers as keras_layers

from ... import layers as ilayers

#---------------------------------------------------FORWARD PASS--------------------------------------------------------

#------------BASICS
@tf.function
def out_func(ins, layer_func):
    print("Tracing out_func...", ins, layer_func)
    return layer_func(ins)

@tf.function
def final_out_func(ins, layer_func, final_mapping, neuron_selection, r_init):
    print("Tracing final out_func...", tf.shape(ins), neuron_selection, r_init)
    output = layer_func(ins)
    output = final_mapping(output, neuron_selection, r_init)
    return output

@tf.function
def neuron_select(Ys, neuron_selection):
    """
    Performs neuron_selection on Ys

    :param Ys: output of own forward pass
    :param neuron_selection: neuron_selection parameter (see try_apply)
    """
    #error handling is done before, in try_apply
    print("Tracing neuron_select", "Ys: ", type(Ys), Ys.shape, " neuron_selection: ", type(neuron_selection), neuron_selection)

    if neuron_selection is None:
        Ys = Ys
    elif isinstance(neuron_selection, tf.Tensor):
        # flatten and then filter neuron_selection index
        Ys = tf.reshape(Ys, (Ys.shape[0], -1))
        Ys = tf.gather_nd(Ys, neuron_selection, batch_dims=1)
    else:
        Ys = K.max(Ys, axis=1, keepdims=True)
    return Ys

#------------GRADIENT BASED

#------------LRP

#---------------------------------------------------EXPLANATIONS--------------------------------------------------------

#------------BASICS
@tf.function
def base_explanation(reversed_outs, n_ins, n_outs):
    """
    function that computes the explanations.
    * Core XAI functionality

    :param reversed_outs: either backpropagated explanation(s) of child layers, or None if this is the last layer
    :param n_ins: int, (expected) number of inputs
    :param n_outs: int, (expected) number of outputs

    :returns explanation, or tensor of multiple explanations if the layer has multiple inputs (one for each)
    """
    print("Tracing base explanation")
    # TODO Leander: consider all cases
    if n_outs > 1:
        ret = keras_layers.Add(dtype=tf.float32)([r for r in reversed_outs])
    elif n_ins > 1:
        ret = [reversed_outs for i in range(n_ins)]
        ret = tf.keras.layers.concatenate(ret, axis=1)
    else:
        ret = reversed_outs
    return ret

#------------GRADIENT BASED
@tf.function
def gradient_explanation(ins, layer_func, out_func, reversed_outs, n_ins, n_outs):
    print("Tracing gradient explanation", ins)

    outs = out_func(ins, layer_func)

    # correct number of outs
    if n_outs > 1:
        outs = [outs for _ in range(n_outs)]

    if n_outs > 1:
        if  n_ins > 1:
            ret = [keras_layers.Add(dtype=tf.float32)(
                [tf.gradients(o, i, grad_ys=r) for o, r in zip(outs, reversed_outs)]) for i in ins]
        else:
            ret = keras_layers.Add(dtype=tf.float32)(
                [tf.gradients(o, ins, grad_ys=r) for o, r in zip(outs, reversed_outs)])
    else:
        if n_ins > 1:
            ret = [tf.gradients(outs, i, grad_ys=reversed_outs) for i in ins]
        else:
            ret = tf.gradients(outs, ins, grad_ys=reversed_outs)

    return ret

@tf.function
def final_gradient_explanation(ins, layer_func, final_mapping, out_func, reversed_outs, n_ins, n_outs, neuron_selection, r_init):
        print("Tracing final gradient explanation", ins)

        outs = tf.squeeze(out_func(ins, layer_func, final_mapping, neuron_selection, r_init))

        # correct number of outs
        if n_outs > 1:
            outs = [outs for _ in range(n_outs)]

        tf.print(tf.shape(outs))

        if n_outs > 1:
            if n_ins > 1:
                ret = [keras_layers.Add(dtype=tf.float32)(
                    [tf.gradients(o, i, grad_ys=r) for o, r in zip(outs, reversed_outs)]) for i in ins]
            else:
                ret = keras_layers.Add(dtype=tf.float32)(
                    [tf.gradients(o, ins, grad_ys=r) for o, r in zip(outs, reversed_outs)])
        else:
            if n_ins > 1:
                ret = [tf.gradients(outs, i, grad_ys=reversed_outs) for i in ins]
            else:
                ret = tf.gradients(outs, ins, grad_ys=reversed_outs)

        return ret

#------------LRP
@tf.function
def zrule_explanation(ins, layer_func, out_func, reversed_outs, n_outs):

    Zs = out_func(ins, layer_func)

    if reversed_outs is None:
        reversed_outs = Zs

    print("Tracing Explanation...")
    # Divide incoming relevance by the activations.
    if n_outs > 1:
        tmp = [ilayers.SafeDivide()([r, Zs]) for r in reversed_outs]
        # Propagate the relevance to input neurons
        # using the gradient.
        tmp2 = [tf.gradients(Zs, ins, grad_ys=t) for t in tmp]
        ret = keras_layers.Add()([keras_layers.Multiply()([ins, t]) for t in tmp2])
    else:
        tmp = ilayers.SafeDivide()([reversed_outs, Zs])
        # Propagate the relevance to input neurons
        # using the gradient.
        tmp2 = tf.gradients(Zs, ins, grad_ys=tmp)
        ret = keras_layers.Multiply()([ins, tmp2[0]])
    return ret

@tf.function
def final_zrule_explanation(ins, layer_func, final_mapping, out_func, reversed_outs, n_outs, neuron_selection, r_init):

    Zs = tf.squeeze(out_func(ins, layer_func, final_mapping, neuron_selection, r_init))

    if reversed_outs is None:
        reversed_outs = Zs

    print("Tracing Final Explanation...")
    # Divide incoming relevance by the activations.
    if n_outs > 1:
        tmp = [ilayers.SafeDivide()([r, Zs]) for r in reversed_outs]
        # Propagate the relevance to input neurons
        # using the gradient.
        tmp2 = [tf.gradients(Zs, ins, grad_ys=t) for t in tmp]
        ret = keras_layers.Add()([keras_layers.Multiply()([ins, t]) for t in tmp2])
    else:
        tmp = ilayers.SafeDivide()([reversed_outs, Zs])
        # Propagate the relevance to input neurons
        # using the gradient.
        tmp2 = tf.gradients(Zs, ins, grad_ys=tmp)
        ret = keras_layers.Multiply()([ins, tmp2[0]])
    return ret