# Get Python six functionality:
from __future__ import\
    absolute_import, print_function, division, unicode_literals


###############################################################################
###############################################################################
###############################################################################


import tensorflow.keras.layers as keras_layers
import tensorflow.keras.models as keras_models
import tensorflow.keras as keras
import tensorflow as tf
import numpy as np


from . import base
from . import wrapper
from .. import layers as ilayers
from .. import utils as iutils
from ..utils import keras as kutils
from ..utils.keras import checks as kchecks
from ..utils.keras import graph as kgraph


__all__ = [
    "BaselineGradient",
    "Gradient",

    "InputTimesGradient",

    "Deconvnet",
    "GuidedBackprop",

    "IntegratedGradients",

    "SmoothGrad",
]


###############################################################################
###############################################################################
###############################################################################


class BaselineGradient(base.AnalyzerNetworkBase):
    """Gradient analyzer based on build-in gradient.

    Returns as analysis the function value with respect to the input.
    The gradient is computed via the build in function.
    Is mainly used for debugging purposes.

    :param model: A Keras model.
    """

    def __init__(self, model, postprocess=None, **kwargs):

        if postprocess not in [None, "abs", "square"]:
            raise ValueError("Parameter 'postprocess' must be either "
                             "None, 'abs', or 'square'.")
        self._postprocess = postprocess

        self._add_model_softmax_check()

        super(BaselineGradient, self).__init__(model, **kwargs)

    def _create_analysis(self, model, stop_analysis_at_tensors=[]):
        tensors_to_analyze = [x for x in iutils.to_list(model.inputs)
                              if x not in stop_analysis_at_tensors]
        # Apply gradient of forward pass.
        ret = iutils.to_list(ilayers.Gradient()(
            tensors_to_analyze+[model.outputs[0]]))

        if self._postprocess == "abs":
            ret = ilayers.Abs()(ret)
        elif self._postprocess == "square":
            ret = ilayers.Square()(ret)

        return iutils.to_list(ret)


class Gradient(base.ReverseAnalyzerBase):
    """Gradient analyzer.

    Returns as analysis the function value with respect to the input.
    The gradient is computed via the librarie's network reverting.

    :param model: A Keras model.
    """

    def __init__(self, model, postprocess=None, **kwargs):

        if postprocess not in [None, "abs", "square"]:
            raise ValueError("Parameter 'postprocess' must be either "
                             "None, 'abs', or 'square'.")
        self._postprocess = postprocess

        self._add_model_softmax_check()

        super(Gradient, self).__init__(model, **kwargs)

    def _head_mapping(self, X):
        return ilayers.OnesLike()(X)
        # todo(alber): Find out why second code path does not work.
        import tensorflow as tf
        return [tf.ones_like(X)]

    def _postprocess_analysis(self, X):
        ret = super(Gradient, self)._postprocess_analysis(X)

        if self._postprocess == "abs":
            ret = ilayers.Abs()(ret)
        elif self._postprocess == "square":
            ret = ilayers.Square()(ret)

        return iutils.to_list(ret)


###############################################################################
###############################################################################
###############################################################################


class InputTimesGradient(Gradient):
    """Input*Gradient analyzer.

    :param model: A Keras model.
    """

    def __init__(self, model, **kwargs):

        self._add_model_softmax_check()

        super(InputTimesGradient, self).__init__(model, **kwargs)

    def _create_analysis(self, model, stop_analysis_at_tensors=[]):
        tensors_to_analyze = [x for x in iutils.to_list(model.inputs)
                              if x not in stop_analysis_at_tensors]
        gradients = super(InputTimesGradient, self)._create_analysis(
            model, stop_analysis_at_tensors=stop_analysis_at_tensors)
        return [keras_layers.Multiply()([i, g])
                for i, g in zip(tensors_to_analyze, gradients)]


###############################################################################
###############################################################################
###############################################################################


class DeconvnetReverseReLULayer(kgraph.ReverseMappingBase):

    def __init__(self, layer, state):
        self._activation = keras_layers.Activation("relu")
        self._layer_wo_relu = kgraph.copy_layer_wo_activation(
            layer,
            name_template="reversed_%s",
        )

    def apply(self, Xs, Ys, reversed_Ys, reverse_state):
        # Apply relus conditioned on backpropagated values.
        reversed_Ys = kutils.apply(self._activation, reversed_Ys)

        # Apply gradient of forward pass without relus.
        Ys_wo_relu = kutils.apply(self._layer_wo_relu, Xs)
        # Apply gradient.
        import tensorflow as tf
        return tf.gradients(Ys_wo_relu, Xs,
                            grad_ys=reversed_Ys,
                            stop_gradients=Xs)


class Deconvnet(base.ReverseAnalyzerBase):
    """Deconvnet analyzer.

    Applies the "deconvnet" algorithm to analyze the model.

    :param model: A Keras model.
    """

    def __init__(self, model, **kwargs):

        self._add_model_softmax_check()
        self._add_model_check(
            lambda layer: not kchecks.only_relu_activation(layer),
            "Deconvnet is only specified for networks with ReLU activations.",
            check_type="exception",
        )

        super(Deconvnet, self).__init__(model, **kwargs)

    def _create_analysis(self, *args, **kwargs):

        self._add_conditional_reverse_mapping(
            lambda layer: kchecks.contains_activation(layer, "relu"),
            DeconvnetReverseReLULayer,
            name="deconvnet_reverse_relu_layer",
        )

        return super(Deconvnet, self)._create_analysis(*args, **kwargs)

def gradient_reverse_map(
    #Alternative to kgraph.reverse_model.
    model, reverse_mappings,
    stop_mapping_at_tensors=[],
    verbose = False):

    #TODO this is just the basic core. Add full functionality of kgraph.reverse_model
    stop_mapping_at_tensors = [x.name.split(":")[0] for x in stop_mapping_at_tensors]

    layers = kgraph.get_model_layers(model)
    replacement_layers = []

    for layer in layers:
        if not layer.name in stop_mapping_at_tensors:
            layer_next = []
            for layer2 in layers:
                inp = layer2.input
                out = layer.output
                if not isinstance(inp, list):
                    inp = [inp]
                if not isinstance(out, list):
                    out = [out]

                for i in inp:
                    if id(i) in [id(o) for o in out] and id(layer) != id(layer2):
                        layer_next.append(layer2)
            replacement_layers.append(ReplacementLayer(layer, reverse_mappings(layer), layer_next))

    return replacement_layers

def apply_reverse_map(Xs, reverse_map, neuron_selection=None, layer_selection=None, ):

    #TODO layer_selection
    #TODO neuron_selection
    #TODO stop_mapping_at_tensors



    _, hm = reverse_map[0].apply(Xs)
    return hm

def GuidedBackpropReverseReLU(Xs, Ys, reversed_Ys, tape):
    activation = keras_layers.Activation("relu")
    reversed_Ys = kutils.apply(activation, reversed_Ys)
    return tape.gradients(Ys, Xs, output_gradients=reversed_Ys)

def GradientReverseMapping(Xs, Ys, reversed_Ys, tape):
    return tape.gradients(Ys, Xs, output_gradients=reversed_Ys)

class ReplacementLayer():
    def __init__(self, layer, method, layer_next=[]):
        self.layer_func = layer
        self.layer_next = layer_next
        self.method = method

    def apply(self, Xs, reversed_Ys=None):
        with tf.GradientTape() as tape:
            tape.watch(Xs)
            Ys = self.layer_func(Xs)
            #TODO: layer_next=None --> last layer. Treat differently
            if reversed_Ys is None and len(self.layer_next) != 0:
                _, reversed_Ys = self.layer_next.apply(Ys)
        ret = self.method(Xs, Ys, reversed_Ys, tape)
        return Ys, ret

class GuidedBackprop(base.ReverseAnalyzerBase):
    """Guided backprop analyzer.

    Applies the "guided backprop" algorithm to analyze the model.

    :param model: A Keras model.
    """

    def __init__(self, model, **kwargs):

        self._add_model_softmax_check()
        self._add_model_check(
            lambda layer: not kchecks.only_relu_activation(layer),
            "GuidedBackprop is only specified for "
            "networks with ReLU activations.",
            check_type="exception",
        )

        super(GuidedBackprop, self).__init__(model, **kwargs)

    def analyze(self, X, neuron_selection=None):
        """
                Same interface as :class:`Analyzer` besides

                :param neuron_selection: If neuron_selection_mode is 'index' this
                  should be an integer with the index for the chosen neuron.
                """
        if not hasattr(self, "_analyzer_model"):
            self.create_analyzer_model()
        pass


    def create_analyzer_model(self):
        """
        Creates the analyze functionality. If not called beforehand
        it will be called by :func:`analyze`.
        """
        model_inputs = self._model.inputs
        tmp = self._prepare_model(self._model)
        model, analysis_inputs, stop_analysis_at_tensors = tmp
        self._analysis_inputs = analysis_inputs
        self._prepared_model = model

        # TODO: different model creation
        tmp = self._create_analysis(
            model, stop_analysis_at_tensors=stop_analysis_at_tensors)

    def _reverse_mapping(self, layer):
        return GradientReverseMapping

    def _create_analysis(self, model, stop_analysis_at_tensors=[]):
        for layer in model.layers:
            self._reverse_mapping(layer)
        ret = gradient_reverse_map(
            model,
            reverse_mappings=self._reverse_mapping,
            stop_mapping_at_tensors=stop_analysis_at_tensors,
            verbose=self._reverse_verbose,
        )

        return ret


###############################################################################
###############################################################################
###############################################################################


class IntegratedGradients(wrapper.PathIntegrator):
    """Integrated gradient analyzer.

    Applies the "integrated gradient" algorithm to analyze the model.

    :param model: A Keras model.
    :param steps: Number of steps to use average along integration path.
    """

    def __init__(self, model, steps=64, **kwargs):
        subanalyzer_kwargs = {}
        kwargs_keys = ["neuron_selection_mode", "postprocess"]
        for key in kwargs_keys:
            if key in kwargs:
                subanalyzer_kwargs[key] = kwargs.pop(key)
        subanalyzer = Gradient(model, **subanalyzer_kwargs)

        super(IntegratedGradients, self).__init__(subanalyzer,
                                                  steps=steps,
                                                  **kwargs)


###############################################################################
###############################################################################
###############################################################################


class SmoothGrad(wrapper.GaussianSmoother):
    """Smooth grad analyzer.

    Applies the "smooth grad" algorithm to analyze the model.

    :param model: A Keras model.
    :param augment_by_n: Number of distortions to average for smoothing.
    """

    def __init__(self, model, augment_by_n=64, **kwargs):
        subanalyzer_kwargs = {}
        kwargs_keys = ["neuron_selection_mode", "postprocess"]
        for key in kwargs_keys:
            if key in kwargs:
                subanalyzer_kwargs[key] = kwargs.pop(key)
        subanalyzer = Gradient(model, **subanalyzer_kwargs)

        super(SmoothGrad, self).__init__(subanalyzer,
                                         augment_by_n=augment_by_n,
                                         **kwargs)
