from tensorflow.keras.layers import Conv2D, Flatten, Dense, Dropout, MaxPooling2D
from tensorflow.keras.models import Sequential
import tensorflow as tf
import innvestigate
import tensorflow.keras as keras
import numpy as np

"""
# Build model

x = tf.constant([[1], [2]], dtype=tf.float16)

#@tf.function
def f(x):
    model = Dense(10)
    ret = model(x)
    return ret

with tf.GradientTape() as tape:
    tape.watch(x)
    # Make prediction
    ret = f(x)

# Calculate gradients
model_gradients = tape.gradient(ret, x)
print(model_gradients)
"""

#inputs = tf.keras.Input(shape=(1,))
#x = tf.keras.layers.Dense(4, activation=tf.nn.relu)(inputs)
#outputs = tf.keras.layers.Dense(5, activation=tf.nn.softmax)(x)
#model = tf.keras.Model(inputs=inputs, outputs=outputs)

model = tf.keras.applications.VGG16(
    include_top=True,
    weights="imagenet",
)

inp = np.random.rand(3, 224, 224, 3)
model = innvestigate.utils.keras.graph.model_wo_softmax(model)
ana = innvestigate.analyzer.new_base.ReverseAnalyzerBase(model, neuron_selection_mode="all")
ana.analyze(inp, neuron_selection=[0, 1, 2])