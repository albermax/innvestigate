innvestigate.tools
==================

Pattern Computation
---------------

.. automodule:: innvestigate.tools.pattern
   :members: PatternComputer
   :undoc-members: BasePattern

Perturbation Analysis
---------------

.. automodule:: innvestigate.tools.perturbate
   :members:
   :undoc-members:

