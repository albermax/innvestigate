innvestigate
============


.. autofunction:: innvestigate.analyzer.create_analyzer
