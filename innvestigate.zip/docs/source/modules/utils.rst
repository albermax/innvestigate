innvestigate.utils
==================

.. automodule:: innvestigate.utils
   :members:
   :undoc-members:

Visualizations
---------------
	  
.. automodule:: innvestigate.utils.visualizations
   :members:
   :undoc-members:

Keras-Utils
------------

.. automodule:: innvestigate.utils.keras.graph
   :members: copy_layer, copy_layer_wo_act, model_wo_softmax, get_model_execution_graph, reverse_model
   :undoc-members:
