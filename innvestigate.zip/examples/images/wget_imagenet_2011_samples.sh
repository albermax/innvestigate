#! /bin/bash
# By using this script you download image data own your own risk and responsibility.
#
# Imagenet 2011 images, full url list is available here: http://image-net.org/imagenet_data/urls/imagenet_winter11_urls.tgz
wget http://farm4.static.flickr.com/3142/2592291184_71735af93e.jpg -O n07720875_13.jpg
wget http://farm1.static.flickr.com/36/122398209_7915b8bcdb.jpg -O n02799071_190.jpg
wget http://farm1.static.flickr.com/165/329702023_cb41c65e84.jpg -O n07615774_348.jpg
wget http://farm3.static.flickr.com/2207/1675176906_8f98de2f96.jpg -O n01978287_43.jpg
#wget http://polardiscovery.whoi.edu/arctic/images/timeline-pargo.jpg -O n04347754_440.jpg
wget http://farm2.static.flickr.com/1292/1155177675_d0d23ede2a.jpg -O n02906734_320.jpg
wget http://farm3.static.flickr.com/2123/2347434732_23d10f8587.jpg -O n02667093_96.jpg
